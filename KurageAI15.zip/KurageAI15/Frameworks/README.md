# Frameworks フォルダについて

ここには `llama.xcframework` が入ります（数十MBあるため、このリポジトリには含めていません）。

- GitHub Actions のビルドでは、公式 ggml-org/llama.cpp リリース（b5046）の
  XCFramework を自動でダウンロードして、ここへ配置します。
- 手元（Mac）でビルドする場合は、公式リポジトリの `build-xcframework.sh` で作った
  `llama.xcframework` を、ここへコピーしてください。
