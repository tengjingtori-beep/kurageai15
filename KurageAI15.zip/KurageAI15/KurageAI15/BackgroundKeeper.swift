import Foundation
import BackgroundTasks

/// バックグラウンド処理の土台。
/// iOS の決まりで、アプリが裏側で長時間動き続けることはできない。
/// ここでは「定期的に目覚めて状態保存を確認する」だけを行い、
/// 長い作業は会話の自動保存（チェックポイント）＋再開でまかなう設計。
enum BackgroundKeeper {
    static let taskIdentifier = "app.hane.kurageai15.refresh"

    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskIdentifier, using: nil) { task in
            // 目覚めたら最終保存時刻を記録して、すぐに正常終了する。
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "kurageai.lastBackgroundCheck")
            task.setTaskCompleted(success: true)
            schedule()
        }
    }

    static func schedule() {
        let request = BGAppRefreshTaskRequest(identifier: taskIdentifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        try? BGTaskScheduler.shared.submit(request)
    }
}
