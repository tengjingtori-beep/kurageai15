import SwiftUI

struct ChatView: View {
    @ObservedObject var viewModel: ChatViewModel
    @ObservedObject var modelManager: ModelManager
    @ObservedObject var fileMaker: FileMaker

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if let notice = viewModel.noticeText {
                    Text(notice)
                        .font(.footnote)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(6)
                        .background(Color.green)
                }
                if let error = viewModel.errorText {
                    Text(error)
                        .font(.footnote)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(6)
                        .background(Color.red)
                }

                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 10) {
                            if viewModel.messages.isEmpty {
                                Text("こんにちは。クラゲAIです。\n完全オフラインで会話できます。\n先に「モデル」タブで GGUF モデルを取り込んでください。")
                                    .padding()
                                    .foregroundColor(.gray)
                            }
                            ForEach(viewModel.messages) { message in
                                HStack {
                                    if message.role == "user" { Spacer(minLength: 40) }
                                    Text(message.text.isEmpty ? "…" : message.text)
                                        .padding(10)
                                        .background(message.role == "user" ? Color.blue : Color(white: 0.92))
                                        .foregroundColor(message.role == "user" ? .white : .black)
                                        .cornerRadius(12)
                                    if message.role != "user" { Spacer(minLength: 40) }
                                }
                                .id(message.id)
                                .padding(.horizontal, 8)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                    .onChange(of: viewModel.messages) { _ in
                        if let last = viewModel.messages.last {
                            withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                        }
                    }
                }

                Divider()
                HStack(alignment: .bottom, spacing: 8) {
                    TextField("メッセージを入力", text: $viewModel.inputText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    if viewModel.isGenerating {
                        Button("止める") { viewModel.stop() }
                            .foregroundColor(.red)
                    } else {
                        Button("送信") {
                            viewModel.send(modelManager: modelManager, fileMaker: fileMaker)
                        }
                        .disabled(viewModel.inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
                .padding(8)
            }
            .navigationBarTitle("クラゲAI", displayMode: .inline)
            .navigationBarItems(trailing: Button("全消去") {
                viewModel.clearHistory()
            })
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
