import Foundation

struct ChatMessage: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String // "user" / "assistant"
    var text: String
}

/// チャット画面の状態管理。
/// 会話はその都度ファイルへ保存する（チェックポイント方式）ため、
/// アプリが途中で終了しても、次回起動時に続きから再開できる。
final class ChatViewModel: NSObject, ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var inputText: String = ""
    @Published var isGenerating: Bool = false
    @Published var errorText: String?
    @Published var noticeText: String?

    let engine = LlamaEngine()
    private var generationTask: Task<Void, Never>?
    private var modelLoadedPath: String?

    private var historyFileURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("chat_history.json")
    }

    override init() {
        super.init()
        loadHistory()
        // ショートカット連携（kurageai://chat?text=...）で渡された文を入力欄へ入れる
        applyPendingPrompt()
        NotificationCenter.default.addObserver(self, selector: #selector(applyPendingPrompt),
                                               name: Notification.Name("kurageai.pendingPromptReceived"), object: nil)
    }

    @objc private func applyPendingPrompt() {
        if let pending = UserDefaults.standard.string(forKey: "kurageai.pendingPrompt"), !pending.isEmpty {
            inputText = pending
            UserDefaults.standard.removeObject(forKey: "kurageai.pendingPrompt")
        }
    }

    // MARK: - 永続化（チェックポイント）

    func saveHistory() {
        if let data = try? JSONEncoder().encode(messages) {
            try? data.write(to: historyFileURL, options: [.atomic])
        }
    }

    private func loadHistory() {
        if let data = try? Data(contentsOf: historyFileURL),
           let saved = try? JSONDecoder().decode([ChatMessage].self, from: data) {
            messages = saved
        }
    }

    func clearHistory() {
        messages = []
        saveHistory()
    }

    // MARK: - 送信

    func send(modelManager: ModelManager, fileMaker: FileMaker) {
        let text = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isGenerating else { return }
        guard let modelURL = modelManager.currentModelURL else {
            errorText = "先に「モデル」タブで GGUF モデルを取り込んでください。"
            return
        }
        inputText = ""
        errorText = nil
        noticeText = nil
        messages.append(ChatMessage(role: "user", text: text))
        messages.append(ChatMessage(role: "assistant", text: ""))
        saveHistory()
        isGenerating = true

        let history = messages.dropLast().map { (role: $0.role, content: $0.text) }
        let assistantIndex = messages.count - 1

        generationTask = Task { [weak self] in
            guard let self = self else { return }
            do {
                if self.modelLoadedPath != modelURL.path {
                    try await self.engine.loadModel(path: modelURL.path)
                    self.modelLoadedPath = modelURL.path
                }
                let full = try await self.engine.generate(
                    messages: [(role: "system", content: SystemPrompt.text)] + history,
                    onToken: { piece in
                        Task { @MainActor in
                            guard assistantIndex < self.messages.count else { return }
                            self.messages[assistantIndex].text += piece
                        }
                    })
                await MainActor.run {
                    if assistantIndex < self.messages.count, self.messages[assistantIndex].text.isEmpty {
                        self.messages[assistantIndex].text = full
                    }
                    self.isGenerating = false
                    self.saveHistory()
                    // ファイル作成指示が含まれていれば実際にファイルを作る
                    let made = fileMaker.createFiles(from: full)
                    if !made.isEmpty {
                        self.noticeText = "ファイルを作りました: " + made.map { $0.name }.joined(separator: "、")
                    }
                }
            } catch {
                await MainActor.run {
                    self.isGenerating = false
                    if assistantIndex < self.messages.count, self.messages[assistantIndex].text.isEmpty {
                        self.messages.remove(at: assistantIndex)
                    }
                    self.errorText = error.localizedDescription
                    self.saveHistory()
                }
            }
        }
    }

    func stop() {
        generationTask?.cancel()
        isGenerating = false
        saveHistory()
    }
}
