import SwiftUI

struct ContentView: View {
    @StateObject private var modelManager = ModelManager()
    @StateObject private var fileMaker = FileMaker()
    @StateObject private var chatViewModel = ChatViewModel()
    @State private var showPicker = false
    @State private var shareItem: CreatedFile?
    @State private var showShare = false

    var body: some View {
        TabView {
            ChatView(viewModel: chatViewModel, modelManager: modelManager, fileMaker: fileMaker)
                .tabItem {
                    Image(systemName: "message.fill")
                    Text("会話")
                }

            filesTab
                .tabItem {
                    Image(systemName: "doc.fill")
                    Text("作ったファイル")
                }

            modelTab
                .tabItem {
                    Image(systemName: "cpu")
                    Text("モデル")
                }
        }
    }

    // MARK: - 作ったファイル一覧

    private var filesTab: some View {
        NavigationView {
            List {
                if fileMaker.files.isEmpty {
                    Text("まだファイルはありません。\n会話で「ファイルを作って」と頼むと、ここに作られます。")
                        .foregroundColor(.gray)
                }
                ForEach(fileMaker.files) { file in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(file.name)
                            Text(file.sizeText)
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Button(action: {
                            shareItem = file
                            showShare = true
                        }) {
                            Image(systemName: "square.and.arrow.up")
                        }
                        .buttonStyle(BorderlessButtonStyle())
                    }
                }
                .onDelete { offsets in
                    for i in offsets { fileMaker.delete(fileMaker.files[i]) }
                }
            }
            .navigationBarTitle("作ったファイル", displayMode: .inline)
            .navigationBarItems(trailing: Button("更新") { fileMaker.reload() })
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .sheet(isPresented: $showShare) {
            if let file = shareItem {
                ShareSheet(items: [file.url])
            }
        }
    }

    // MARK: - モデル管理

    private var modelTab: some View {
        NavigationView {
            Form {
                Section(header: Text("今のモデル")) {
                    Text(modelManager.statusMessage)
                    if modelManager.isImporting {
                        ProgressView()
                    }
                }
                Section {
                    Button("GGUF モデルを取り込む") {
                        showPicker = true
                    }
                }
                Section(header: Text("モデルの入れ方")) {
                    Text("モデルのファイル（.gguf）はアプリに入っていません。パソコンや SD カードから取り込んでください。SD カードリーダーをつなげば、「ファイル」アプリから SD カード内のモデルを選べます。")
                    Text("iPhone 7 では、0.5B〜1.5B 級の Q4 モデルが現実的です。大きいモデルはメモリ不足で動きません。")
                }
                Section(header: Text("正直な限界")) {
                    Text("・iPhone 全体の操作は、iOS の決まりでできません。できるのはこのアプリの中の作業です。")
                    Text("・寝ている間の作業は、iOS のバックグラウンド制限の中でだけです。会話は自動で保存されるので、途中で止まっても続きから再開できます。")
                    Text("・日本語の間違いゼロは保証できません。日本語専用の指示で最大限減らしています。")
                }
            }
            .navigationBarTitle("モデルと設定", displayMode: .inline)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .sheet(isPresented: $showPicker) {
            DocumentPicker { url in
                modelManager.importModel(from: url)
            }
        }
    }
}
