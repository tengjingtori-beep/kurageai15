import Foundation

struct CreatedFile: Identifiable, Equatable {
    var id: String { url.path }
    let url: URL
    var name: String { url.lastPathComponent }
    var sizeText: String {
        let bytes = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber) ?? 0
        return ByteCountFormatter.string(fromByteCount: bytes.int64Value, countStyle: .file)
    }
}

/// AI の返答に含まれるファイル作成指示（システムプロンプトで定めた書式）を読み取り、
/// アプリ内フォルダ Documents/CreatedFiles に実際のファイルを作る。
/// 書式:
/// ```file:ファイル名.txt
/// 中身
/// ```
final class FileMaker: ObservableObject {
    @Published var files: [CreatedFile] = []

    var filesDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("CreatedFiles", isDirectory: true)
    }

    init() {
        reload()
    }

    func reload() {
        try? FileManager.default.createDirectory(at: filesDirectory, withIntermediateDirectories: true)
        let urls = (try? FileManager.default.contentsOfDirectory(at: filesDirectory,
                                                                 includingPropertiesForKeys: nil)) ?? []
        files = urls.sorted { $0.lastPathComponent < $1.lastPathComponent }
            .map { CreatedFile(url: $0) }
    }

    /// AI 返答を走査し、ファイル作成ブロックがあればファイルを作る。作ったファイルを返す。
    @discardableResult
    func createFiles(from assistantText: String) -> [CreatedFile] {
        var made: [CreatedFile] = []
        let pattern = "```file:([^\\n`]+)\\n(.*?)\\n```"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) else {
            return made
        }
        let ns = assistantText as NSString
        for match in regex.matches(in: assistantText, options: [], range: NSRange(location: 0, length: ns.length)) {
            guard match.numberOfRanges == 3 else { continue }
            var fileName = ns.substring(with: match.range(at: 1))
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let body = ns.substring(with: match.range(at: 2))
            fileName = sanitize(fileName)
            if fileName.isEmpty { continue }
            let url = uniqueURL(for: fileName)
            do {
                try body.write(to: url, atomically: true, encoding: .utf8)
                made.append(CreatedFile(url: url))
            } catch {
                // 書き込み失敗は黙って次へ（会話自体は止めない）
            }
        }
        if !made.isEmpty { reload() }
        return made
    }

    func delete(_ file: CreatedFile) {
        try? FileManager.default.removeItem(at: file.url)
        reload()
    }

    /// パス区切りや危険な文字を取り除き、単純なファイル名だけにする。
    private func sanitize(_ name: String) -> String {
        var s = name.replacingOccurrences(of: "/", with: "_")
        s = s.replacingOccurrences(of: "\\", with: "_")
        s = s.replacingOccurrences(of: ":", with: "_")
        s = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.hasPrefix(".") { s = "_" + s }
        return s
    }

    /// 同名ファイルがある場合は「名前 2.txt」のように連番を付ける。
    private func uniqueURL(for fileName: String) -> URL {
        var candidate = filesDirectory.appendingPathComponent(fileName)
        if !FileManager.default.fileExists(atPath: candidate.path) { return candidate }
        let ext = candidate.pathExtension
        let base = candidate.deletingPathExtension().lastPathComponent
        var i = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            let next = ext.isEmpty ? "\(base) \(i)" : "\(base) \(i).\(ext)"
            candidate = filesDirectory.appendingPathComponent(next)
            i += 1
        }
        return candidate
    }
}
