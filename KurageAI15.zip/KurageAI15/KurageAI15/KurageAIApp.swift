import SwiftUI

@main
struct KurageAIApp: App {
    init() {
        BackgroundKeeper.register()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .onOpenURL { url in
                    handleOpenURL(url)
                }
        }
    }

    /// ショートカット連携の入口。
    /// kurageai://chat?text=こんにちは の形で開くと、文を入力欄に入れる。
    private func handleOpenURL(_ url: URL) {
        guard url.scheme == "kurageai" else { return }
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        if let text = components?.queryItems?.first(where: { $0.name == "text" })?.value, !text.isEmpty {
            UserDefaults.standard.set(text, forKey: "kurageai.pendingPrompt")
            NotificationCenter.default.post(name: Notification.Name("kurageai.pendingPromptReceived"), object: nil)
        }
    }
}
