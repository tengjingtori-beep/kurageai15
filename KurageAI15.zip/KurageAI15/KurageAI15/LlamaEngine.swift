import Foundation
import llama

// llama.cpp の C API を Swift から使うための薄いラッパー。
// 使い方は公式サンプル examples/llama.swiftui/llama.cpp.swift/LibLlama.swift と
// examples/batched.swift の作法に合わせている（2026-11-14 に公式リポジトリで確認）。
// - モデル読み込み: llama_load_model_from_file
// - 文脈作成:      llama_new_context_with_model
// - サンプリング:  llama_sampler_chain_init + top_k / top_p / temp / dist
// - 推論:          llama_decode
// 会話のたびに文脈を作り直す方式なので、KVキャッシュ消去系の API には依存しない。

enum LlamaEngineError: Error, LocalizedError {
    case modelLoadFailed
    case contextInitFailed
    case samplerInitFailed
    case decodeFailed
    case templateFailed

    var errorDescription: String? {
        switch self {
        case .modelLoadFailed: return "モデルを読み込めませんでした。ファイルが壊れているか、対応していない形式です。"
        case .contextInitFailed: return "推論の準備に失敗しました。メモリ不足の可能性があります。"
        case .samplerInitFailed: return "サンプラーの準備に失敗しました。"
        case .decodeFailed: return "推論中にエラーが起きました。"
        case .templateFailed: return "会話テンプレートの適用に失敗しました。"
        }
    }
}

private func kurageBatchClear(_ batch: inout llama_batch) {
    batch.n_tokens = 0
}

private func kurageBatchAdd(_ batch: inout llama_batch,
                             _ id: llama_token,
                             _ pos: llama_pos,
                             _ seqIds: [llama_seq_id],
                             _ logits: Bool) {
    let n = Int(batch.n_tokens)
    batch.token[n] = id
    batch.pos[n] = pos
    batch.n_seq_id[n] = Int32(seqIds.count)
    if let seqIdArray = batch.seq_id[n] {
        for (i, s) in seqIds.enumerated() {
            seqIdArray[i] = s
        }
    }
    batch.logits[n] = logits ? 1 : 0
    batch.n_tokens += 1
}

actor LlamaEngine {
    private var model: OpaquePointer?

    var isLoaded: Bool { model != nil }

    /// GGUF モデルを読み込む。iPhone 7（RAM 2GB級）向けに GPU オフロードは使わず CPU 推論にする。
    func loadModel(path: String) throws {
        unloadModel()
        llama_backend_init()
        var modelParams = llama_model_default_params()
        modelParams.n_gpu_layers = 0 // A10 では CPU 推論が安定。Metal はメモリ圧迫の原因になるため使わない。
        guard let loaded = llama_load_model_from_file(path, modelParams) else {
            throw LlamaEngineError.modelLoadFailed
        }
        model = loaded
    }

    func unloadModel() {
        if let model = model {
            llama_model_free(model)
            self.model = nil
        }
    }

    /// 会話履歴からプロンプト文字列を作る。モデルのチャットテンプレートを優先し、
    /// 使えないモデルでは ChatML 形式にフォールバックする。
    private func buildPrompt(messages: [(role: String, content: String)]) throws -> String {
        guard let model = model else { throw LlamaEngineError.modelLoadFailed }

        // llama_chat_apply_template 用に C 文字列を確保する
        var rolePtrs: [UnsafeMutablePointer<CChar>] = []
        var contentPtrs: [UnsafeMutablePointer<CChar>] = []
        defer {
            rolePtrs.forEach { free($0) }
            contentPtrs.forEach { free($0) }
        }
        var chatMessages: [llama_chat_message] = []
        for m in messages {
            guard let r = strdup(m.role), let c = strdup(m.content) else { continue }
            rolePtrs.append(r)
            contentPtrs.append(c)
            chatMessages.append(llama_chat_message(role: r, content: c))
        }

        let capacity = 32768
        var buffer = [CChar](repeating: 0, count: capacity)
        let written = llama_chat_apply_template(model, nil, chatMessages, chatMessages.count, true, &buffer, Int32(capacity))
        if written > 0 {
            return String(cString: buffer)
        }

        // フォールバック: ChatML 形式（Qwen 系など多くの日本語モデルが採用）
        var text = ""
        for m in messages {
            text += "<|im_start|>\(m.role)\n\(m.content)<|im_end|>\n"
        }
        text += "<|im_start|>assistant\n"
        return text
    }

    private func tokenize(text: String, addSpecial: Bool) -> [llama_token] {
        guard let model = model else { return [] }
        let vocab = llama_model_get_vocab(model)
        let utf8Count = Int32(text.utf8.count)
        let needed = llama_tokenize(vocab, text, utf8Count, nil, 0, addSpecial, false)
        guard needed < 0 else { return [] }
        var tokens = [llama_token](repeating: 0, count: Int(-needed))
        let count = llama_tokenize(vocab, text, utf8Count, &tokens, -needed, addSpecial, false)
        guard count > 0 else { return [] }
        return Array(tokens.prefix(Int(count)))
    }

    private func tokenToPiece(_ token: llama_token) -> String {
        guard let model = model else { return "" }
        let vocab = llama_model_get_vocab(model)
        var buffer = [CChar](repeating: 0, count: 256)
        let n = llama_token_to_piece(vocab, token, &buffer, Int32(buffer.count), 0, false)
        guard n > 0 else { return "" }
        let bytes = buffer.prefix(Int(n)).map { UInt8(bitPattern: $0) }
        return String(decoding: bytes, as: UTF8.self)
    }

    /// 1回分の返答を生成する。トークンは onToken で逐次返す。
    /// 文脈は毎回作り直す（モデル本体は使い回す）ので、途中で止まっても状態が壊れない。
    func generate(messages: [(role: String, content: String)],
                  maxTokens: Int = 512,
                  onToken: @escaping @Sendable (String) -> Void) async throws -> String {
        guard let model = model else { throw LlamaEngineError.modelLoadFailed }
        let prompt = try buildPrompt(messages: messages)

        var ctxParams = llama_context_default_params()
        ctxParams.n_ctx = 2048
        ctxParams.n_batch = 512
        ctxParams.n_threads = 2 // iPhone 7 の高性能コア数に合わせる
        ctxParams.n_threads_batch = 2

        guard let context = llama_new_context_with_model(model, ctxParams) else {
            throw LlamaEngineError.contextInitFailed
        }
        defer { llama_free(context) }

        // サンプラー（公式 batched.swift サンプルの構成）
        var samplerParams = llama_sampler_chain_default_params()
        samplerParams.no_perf = true
        guard let sampler = llama_sampler_chain_init(samplerParams) else {
            throw LlamaEngineError.samplerInitFailed
        }
        defer { llama_sampler_free(sampler) }
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40))
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.95, 1))
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7))
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(42))

        var batch = llama_batch_init(512, 0, 1)
        defer { llama_batch_free(batch) }

        // プロンプト投入
        let promptTokens = tokenize(text: prompt, addSpecial: true)
        guard !promptTokens.isEmpty else { throw LlamaEngineError.decodeFailed }
        kurageBatchClear(&batch)
        for (i, token) in promptTokens.enumerated() {
            kurageBatchAdd(&batch, token, llama_pos(i), [0], i == promptTokens.count - 1)
        }
        guard llama_decode(context, batch) == 0 else { throw LlamaEngineError.decodeFailed }

        let vocab = llama_model_get_vocab(model)
        var result = ""
        var generated: Int32 = 0
        var currentPos = llama_pos(promptTokens.count)

        while generated < Int32(maxTokens) {
            if Task.isCancelled { break }
            let newToken = llama_sampler_sample(sampler, context, -1)
            llama_sampler_accept(sampler, newToken)
            if llama_vocab_is_eog(vocab, newToken) { break }

            let piece = tokenToPiece(newToken)
            if !piece.isEmpty {
                result += piece
                onToken(piece)
            }
            generated += 1

            kurageBatchClear(&batch)
            kurageBatchAdd(&batch, newToken, currentPos, [0], true)
            currentPos += 1
            guard llama_decode(context, batch) == 0 else { throw LlamaEngineError.decodeFailed }
        }
        return result
    }
}
