import Foundation

/// GGUF モデルの取り込みと保持を担当する。
/// モデルは数GBになるためアプリには同梱せず、ドキュメントピッカーで選んだファイルを
/// アプリの Documents/Models へコピーして使う。
/// Lightning 用 SD カードリーダーを使えば、ファイルアプリ経由で SD カード内の
/// モデルもそのまま選べる（＝このアプリでの「SD接続で認識」の実現形）。
final class ModelManager: ObservableObject {
    @Published var modelName: String?
    @Published var statusMessage: String = "モデルが未選択です"
    @Published var isImporting: Bool = false

    private let bookmarkKey = "kurageai.modelBookmark"
    private let nameKey = "kurageai.modelName"

    var modelsDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("Models", isDirectory: true)
    }

    init() {
        restoreBookmark()
    }

    /// 前回選んだモデルをブックマークから復元する。
    func restoreBookmark() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        var stale = false
        if let url = try? URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale),
           FileManager.default.fileExists(atPath: url.path) {
            modelName = UserDefaults.standard.string(forKey: nameKey) ?? url.lastPathComponent
            statusMessage = "モデル準備OK: \(modelName ?? "")"
        }
    }

    /// 現在選択中のモデルファイルの URL（コピー済みの実体）。
    var currentModelURL: URL? {
        guard let name = modelName else { return nil }
        let url = modelsDirectory.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    /// ドキュメントピッカーで選ばれたファイルを取り込む。
    func importModel(from pickedURL: URL) {
        isImporting = true
        statusMessage = "モデルを取り込み中です…（大きいファイルは時間がかかります）"
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let scoped = pickedURL.startAccessingSecurityScopedResource()
            defer { if scoped { pickedURL.stopAccessingSecurityScopedResource() } }
            do {
                try FileManager.default.createDirectory(at: self.modelsDirectory, withIntermediateDirectories: true)
                let dest = self.modelsDirectory.appendingPathComponent(pickedURL.lastPathComponent)
                if FileManager.default.fileExists(atPath: dest.path) {
                    try FileManager.default.removeItem(at: dest)
                }
                try FileManager.default.copyItem(at: pickedURL, to: dest)
                let bookmark = try dest.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
                UserDefaults.standard.set(bookmark, forKey: self.bookmarkKey)
                UserDefaults.standard.set(dest.lastPathComponent, forKey: self.nameKey)
                DispatchQueue.main.async {
                    self.modelName = dest.lastPathComponent
                    self.isImporting = false
                    self.statusMessage = "モデル準備OK: \(dest.lastPathComponent)"
                }
            } catch {
                DispatchQueue.main.async {
                    self.isImporting = false
                    self.statusMessage = "取り込みに失敗しました: \(error.localizedDescription)"
                }
            }
        }
    }
}
